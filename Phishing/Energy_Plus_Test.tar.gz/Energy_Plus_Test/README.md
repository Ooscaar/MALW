# ENERGY PLUS Connection tests

This ansible program is used to automate some software engineering tasks in Energy Plus equipments.
In next section the main utilities are described.
-------------------

* **ping.yml**: This playbook makes ping test.

* **ifconfig.yml**: This playbook checks is there config.file.

* **prepare_nodes.yml**: This playbook prepares nodes for work.

* **update.yml**: This playbook updates all packages on host.



